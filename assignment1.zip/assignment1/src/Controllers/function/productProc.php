<?php

//get all products
function getAllProducts($db)
{
    $sql = 'Select p.product_name, p.brand_id, p.category_id, p.model_year, p.list_price from products p ';
    $stmt = $db->prepare ($sql);
    $stmt ->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//get product by id
function getProduct($db, $productId)
{
    $sql = 'Select p.product_name, p.brand_id, p.category_id, p.model_year, p.list_price from products p ';
    $sql .= 'Where p.id = :id';
    $stmt = $db->prepare ($sql);
    $id = (int) $productId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

//add new product
function createProduct($db, $form_data)
{
    $sql = 'Insert into products (product_name, brand_id, category_id, model_year, list_price) ';
    $sql .= 'values (:product_name, :brand_id, :category_id, :model_year, :list_price) ';
    $stmt = $db->prepare ($sql);
    $stmt->bindParam(':product_name', $form_data['product_name']);
    $stmt->bindParam(':brand_id', $form_data['brand_id']);
    $stmt->bindParam(':category_id', $form_data['category_id']);
    $stmt->bindParam(':model_year', $form_data['model_year']);
    $stmt->bindParam(':list_price', $form_data['list_price']);
    $stmt->execute();
    return $db->lastInsertID(); //insert last number.. continue
}

//delete product by id
function deleteProduct($db,$productId)
{
    $sql = ' Delete from products where id = :id';
    $stmt = $db->prepare($sql);
    $id = (int)$productId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
}

//update product by id
function updateProduct($db,$form_dat,$productId)
{
    $sql = 'UPDATE products SET product_name = :product_name , brand_id = :brand_id , category_id = :category_id , model_year = :model_year , list_price = :list_price ';
    $sql .=' WHERE id = :id';
    $stmt = $db->prepare ($sql);
    $id = (int)$productId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':product_name', $form_dat['product_name']);
    $stmt->bindParam(':brand_id', $form_dat['brand_id']);
    $stmt->bindParam(':category_id', $form_dat['category_id']);
    $stmt->bindParam(':model_year', $form_dat['model_year']);
    $stmt->bindParam(':list_price', $form_dat['list_price']);
    $stmt->execute();
}